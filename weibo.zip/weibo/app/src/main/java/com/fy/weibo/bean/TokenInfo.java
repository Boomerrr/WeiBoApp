package com.fy.weibo.bean;

/**
 * Created by Fan on 2018/8/24.
 * Fighting!!!
 */
public final class TokenInfo {



    private String uid;
    private String create_at;
    private String expire_in;

    public String getUid() {
        return uid;
    }


    public String getCreate_at() {
        return create_at;
    }


    public String getExpire_in() {
        return expire_in;
    }

}

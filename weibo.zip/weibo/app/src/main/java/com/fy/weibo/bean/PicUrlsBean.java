package com.fy.weibo.bean;

import java.io.Serializable;

/**
 * Created by Fan on 2018/8/20.
 * Fighting!!!
 */
public final class PicUrlsBean implements Serializable{

    private String thumbnail_pic;

    public String getThumbnail_pic() {
        return thumbnail_pic;
    }

}

package com.fy.weibo.interfaces;

/**
 * Created by Fan on 2018/8/28.
 * Fighting!!!
 */
public interface IModel {


}

package com.fy.weibo.bean;

/**
 * Created by Fan on 2018/8/24.
 * Fighting!!!
 */
public final class UserCounts {



    private String id;
    private String  followers_count;
    private String friends_count;
    private String statuses_count;

    public String getId() {
        return id;
    }


    public String getFollowers_count() {
        return followers_count;
    }


    public String getFriends_count() {
        return friends_count;
    }


    public String getStatuses_count() {
        return statuses_count;
    }

}
